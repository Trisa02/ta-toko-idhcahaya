<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .pagination li{
            float: left;
            list-style-type: none;
            margin: 5px;
        }
    </style>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Data Produk Idh.Cahaya</h6>
                <a href="<?php echo e(route('tambah-barang')); ?>">Tambah Produk</a>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col">No</th>
                            <th scope="col">Nama Barang</th>
                            <th scope="col">Nama Kategori</th>
                            <th scope="col">Stok</th>
                            <th scope="col">harga</th>
                            <th scope="col">berat</th>
                            <th scope="col">Detail</th>
                            <th scope="col">slug</th>
                            <th scope="col">Gambar</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i +1); ?></td>
                                <td><?php echo e($isi->nama_barang); ?></td>
                                <td><?php echo e($isi->nama_kategori); ?></td>
                                <td><?php echo e($isi->stok); ?></td>
                                <td><?php echo e($isi->harga); ?></td>
                                <td><?php echo e($isi->berat); ?></td>
                                <td><?php echo e($isi->detail); ?></td>
                                <td><?php echo e($isi->slug_barang); ?></td>
                                <td><img src="<?php echo e(asset('gambar/'. $isi->gambar)); ?>" width="100%" alt=""></td>
                                <td><a href="<?php echo e(route('edit-barang',$isi->id_barang)); ?>" class=" btn btn-warning btn-block "><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('hapus-barang',$isi->id_barang)); ?>" class=" btn btn-danger  btn-block "><i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <br/>
                <?php echo e($barang->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/barang/viewbarang.blade.php ENDPATH**/ ?>