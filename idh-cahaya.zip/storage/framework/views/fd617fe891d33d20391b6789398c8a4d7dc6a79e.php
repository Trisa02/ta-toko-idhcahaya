
<?php $__env->startSection('content'); ?>
<section class="checkout spad">
    <div class="container">
        <div class="checkout__form">
            <h4>Akun Saya</h4>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('edit-akun',$akun->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-10 col-md-8">
                        <div class="checkout__order">
                            <h4>Profil Saya</h4>
                            <div class="checkout__input">
                                <img src="<?php echo e(asset('gambar/'.$akun->gambar)); ?>" width="30%" height="30%" class="rounded-circle" alt="Cinque Terre">
                                <input type="file" name="gambar" >
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Nama Lengkap</p>
                                        <input type="text" class="text-dark" value="<?php echo e($akun->nama_member); ?>" name="nama_member">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Username</p>
                                        <input type="text" class="text-dark" value="<?php echo e($akun->username_member); ?>" name="username_member">
                                    </div>
                                </div>
                            </div>
                            <div class="checkout__input">
                                <p>Email</p>
                                <input type="text" class="text-dark" value="<?php echo e($akun->email_member); ?>" name="email_member">
                            </div>
                            <div class="checkout__input">
                                <p>No Telepon</p>
                                <input type="text" class="text-dark" value="<?php echo e($akun->no_telepon); ?>" name="no_telepon">
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <p>Provinsi</p>
                                        <select class="form-control provinsi-tujuan" name="province_destination" style="width: 90%">
                                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($province); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <p>Kota/Kabupaten</p>
                                        <select class="form-control kota-tujuan" name="city_destination" style="width: 90%">
                                            <option value="">-- Pilih Kota --</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="checkout__input">
                                <p>Alamat Lengkap</p>
                                <textarea cols="100" rows="5" name="alamat_member"><?php echo e($akun->alamat_member); ?></textarea>
                            </div>

                            <div class="col-12">
                                <button type="submit" style="height:50px;width:150px" class="btn btn-success btn-md">Simpan Akun</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </section>
    <script>
    $(document).ready(function(){
     //active select2
     $(".provinsi-asal , .kota-asal, .provinsi-tujuan, .kota-tujuan").select2({
         theme:'bootstrap4',width:'style',
     });
     //ajax select kota tujuan
     $('select[name="province_destination"]').on('change', function () {
         let provindeId = $(this).val();
         if (provindeId) {
             jQuery.ajax({
                 url: '/cities-akun/'+provindeId,
                 type: "GET",
                 dataType: "json",
                 success: function (response) {
                     $('select[name="city_destination"]').empty();
                     $('select[name="city_destination"]').append('<option value="">-- pilih kota tujuan --</option>');
                     $.each(response, function (key, value) {
                         $('select[name="city_destination"]').append('<option value="' + key + '">' + value + '</option>');
                     });
                 },
             });
         } else {
             $('select[name="city_destination"]').append('<option value="">-- pilih kota tujuan --</option>');
         }
     });
     //ajax check ongkir
    });
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/Frontend/Akun/akun.blade.php ENDPATH**/ ?>