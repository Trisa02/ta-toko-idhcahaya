
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Tabel Data Admin Idh.Cahaya</h6>
                <a href="<?php echo e(route('tambah-admin')); ?>">Tambah Admin</a>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col">No</th>
                            <th scope="col">Nama Admin</th>
                            <th scope="col">Username</th>
                            <th scope="col">Level</th>
                            <th scope="col">Gambar</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $dataadmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i +1); ?></td>
                                <td><?php echo e($isi->nama_admin); ?></td>
                                <td><?php echo e($isi->username); ?></td>
                                <td><?php echo e($isi->level_user); ?></td>
                                <td><img src="<?php echo e(asset('gambar/'. $isi->gambar)); ?>" width="20%" alt=""></td>
                                <td><a href="<?php echo e(route('edit-admin',$isi->id_admin)); ?>" class=" btn btn-warning btn-block "><i class="fa fa-edit"></i></a>
                                    <br>
                                    <a href="<?php echo e(route('hapus-admin',$isi->id_admin)); ?>" class=" btn btn-danger  btn-block "><i class="fa fa-trash"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        toastr.success('Data Berhasil Ditambahkan');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/admin/view_admin.blade.php ENDPATH**/ ?>