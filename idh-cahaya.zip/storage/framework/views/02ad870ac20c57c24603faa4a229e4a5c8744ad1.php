
<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .pagination li{
            float: left;
            list-style-type: none;
            margin: 5px;
        }
    </style>
    <div class="container-fluid pt-4 ">
        <div class="bg-light text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Data Transaksi Idh.Cahaya</h6>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark text-center">
                            <th scope="col">No</th>
                            <th scope="col">Invoice</th>
                            <th scope="col">Nama Pembeli</th>
                            <th scope="col">Pengiriman</th>
                            <th scope="col">Metode Pembayaran</th>
                            <th scope="col">Status Transaksi</th>
                            <th scope="col">Waktu Transaksi</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><span class="badge bg-secondary"><?php echo e($item->order_id); ?></span></td>
                            <td><?php echo e($item->nama_member); ?></td>

                            <td style="width: 30%">
                                <ul>Kurir : <?php echo e($item->kurir); ?></ul>
                                <ul>Ongkir : <?php echo e(number_format( $item->ongkir)); ?></ul>
                                <ul>Total Bayar : <?php echo e(number_format($item->total_bayar)); ?></ul>
                            </td>
                            <td><?php echo e($item->payment_type); ?></td>
                            <td> <span class="badge bg-primary"><?php echo e($item->transaction_status); ?></span> </td>
                            <td><?php echo e(date('d-m-Y H:i:s', strtotime( $item->transaction_time))); ?></td>
                            <td style="width: 20%">
                                <?php if($item->transaction_status == 'settlement'): ?>
                                    <?php if($item->nomor_resi == null): ?>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($item->order_id); ?>">
                                        <i class="fa fa-edit"></i> input resi
                                      </button>
                                    <?php else: ?>
                                    <i class="text-primary">resi : <?php echo e($item->nomor_resi); ?></i>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <br>
                                <a onclick="return confirm('yakin???')" href="<?php echo e(route('transaksi.delete', ['id' => $item->id_transaksi])); ?>" class="btn btn-danger mt-2"><i class="fa fa-trash"></i> Delete</a>
                            </td>
                        </tr>

                         <!-- Modal -->
                        <div class="modal fade" id="exampleModal<?php echo e($item->order_id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Nomor Resi</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <h6 style="text-align: left">Invoice : <?php echo e($item->order_id); ?></h6>
                                    <h6 style="text-align: left">Nama Pembeli : <?php echo e($item->nama_member); ?></h6>
                                    <h6 style="text-align: left">Status Transaksi : <span class="badge bg-primary"><?php echo e($item->transaction_status); ?></span></h6>
                                    <hr>
                                    <form action="<?php echo e(route('transaksi.store_resi')); ?>" method="POST">
                                        <input type="hidden" name="order_id" value="<?php echo e($item->order_id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <h6>Input Nomor Resi</h6>
                                            <input type="text" name="nomor_resi" id="" class="form-control">
                                        </div>

                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>
                            </form>
                            </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/transaksi/index.blade.php ENDPATH**/ ?>