
<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .pagination li{
            float: left;
            list-style-type: none;
            margin: 5px;
        }
    </style>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Data Kategori Idh.Cahaya</h6>
                <a href="<?php echo e(route('tambah-kategori')); ?>">Tambah Kategori</a>
            </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col">No</th>
                            <th scope="col">Nama Kategori Barang</th>
                            <th scope="col">Slug Kategori Barang</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i +1); ?></td>
                                <td><?php echo e($isi->nama_kategori); ?></td>
                                <td><?php echo e($isi->slug_kategori); ?></td>
                                <td><a href="<?php echo e(route('edit-kategori',$isi->id_kategori)); ?>" class=" btn btn-warning btn-block "><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('hapus-kategori',$isi->id_kategori)); ?>" class=" btn btn-danger  btn-block "><i class="fa fa-trash"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($kategori->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/kategori/view_kategori.blade.php ENDPATH**/ ?>