
<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row g-8">
            <div class="col-sm-20 col-xl-10">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Tambah Barang Idh.Cahaya</h6>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                     <?php endif; ?>
                    <form class="row g-3" enctype="multipart/form-data" action="<?php echo e(route('save-barang')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-6">
                          <label for="nama_barang" class="form-label">Nama Barang</label>
                          <input type="text" class="form-control" name="nama_barang">
                        </div>
                        <div class="col-md-6">
                            <label for="nama_kategori" class="form-label">Nama Kategori</label>
                            <select id="nama_kategori" name="id_kategori" class="form-select">
                                <option selected>Pilih Kategori...</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($isi->id_kategori); ?>"><?php echo e($isi->nama_kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="text" name="stok" class="form-control" id="stok">
                        </div>
                        <div class="col-md-4">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="text" name="harga" class="form-control" id="harga">
                        </div>
                        <div class="col-md-2">
                            <label for="berat" class="form-label">Berat</label>
                            <input type="text" name="berat" class="form-control" id="berat">
                        </div>
                        <div class="col-12">
                          <label for="detail" class="form-label">Detail Barang</label>
                          <textarea class="form-control" name="detail" cols="30" rows="5"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="">Gambar</label>
                            <input type="file" name="gambar" class="form-control" placeholder="Gambar">
                        </div>
                        <div class="col-12">
                          <button type="submit" class="btn btn-primary">Save Barang</button>
                        </div>

                      </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/barang/tambah_barang.blade.php ENDPATH**/ ?>