<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    <center>
        <font size="5"><b>Laporan Penjualan IDH.Cahaya</b></font><br>
        <font size="3"><b>Jl. Trans Sumatera Bukittinggi - Padang Sidempuan</b></font><br>
        <font size="3"><b>Ganggo Mudiak, Kec. Bonjol, Kabupaten Pasaman, Sumatera Barat</b></font><br>
        <font size="3"><b>Telp : +62 83193730772, Email : Idh.Cahaya@gmail.com</b></font>

    </center>
    <br>
    <table border="1" style="border-collapse: collapse; width: 100%">
        <thead>
            <tr class="text-dark text-center">
                <th scope="col">No</th>
                <th scope="col">Invoice</th>
                <th scope="col">Nama Member</th>
                <th scope="col">Pengiriman</th>
                <th scope="col">Payment Type</th>
                <th scope="col">Transaction Status</th>
                <th scope="col">Transaction Time</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><span class="badge bg-secondary"><?php echo e($item->order_id); ?></span></td>
                <td><?php echo e($item->nama_member); ?></td>

                <td style="width: 30%">
                    <ul>Kurir : <?php echo e($item->kurir); ?></ul>
                    <ul>Ongkir : <?php echo e(number_format( $item->ongkir)); ?></ul>
                    <ul>Total Bayar : <?php echo e(number_format($item->total_bayar)); ?></ul>
                </td>
                <td><?php echo e($item->payment_type); ?></td>
                <td> <span class="badge bg-primary"><?php echo e($item->transaction_status); ?></span> </td>
                <td><?php echo e(date('d-m-Y H:i:s', strtotime( $item->transaction_time))); ?></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/laporan/cetak.blade.php ENDPATH**/ ?>