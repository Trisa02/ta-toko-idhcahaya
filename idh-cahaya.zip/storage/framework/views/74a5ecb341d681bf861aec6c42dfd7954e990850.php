<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('/')); ?>img/banner2.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2 class="text-dark">Detail Produk</h2>
                    <div class="breadcrumb__option">
                        <a href="<?php echo e(route('index-frontend')); ?>">Home</a>
                        <a href="./index.html">Detail Produk</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Product Details Section Begin -->
<section class="product-details spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4">
                <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product__details__pic">
                    <div class="product__details__pic__item">
                        <img class="product__details__pic__item--large"
                            src="<?php echo e(asset('gambar/'.$dtl->gambar)); ?>" alt="">
                    </div>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-md-6">
                    <div class="product__details__text">
                        <h3><?php echo e($dtl->nama_barang); ?></h3>
                        <div class="product__details__price">Rp.<?php echo e(number_format($dtl->harga)); ?></div>
                        <p><?php echo e($dtl->detail); ?></p>
                        <div class="product__details__quantity">
                            <div class="quantity">
                                <div class="">
                                    <input type="number" id="input-qty" min="1" value="1" class="form-control mb-3" style="width: 40%">
                                </div>
                            </div>
                        </div>
                        <form action="<?php echo e(route('simpan-keranjang')); ?>" method="post"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_barang" value="<?php echo e($dtl->id_barang); ?>" >
                            <input type="hidden" name="tanggal" id="tanggal" >
                            <input type="hidden" name="qty" id="qty" value="1" >
                            <input type="hidden" name="total" id="total">
                            <button class="primary-btn plus float-right" data-toggle="tooltip" data-placement="right" title="Keranjang">Keranjang</button>
                        </form>
                        
                        <form action="<?php echo e(route('simpan-beli')); ?>" method="post"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_barang" value="<?php echo e($dtl->id_barang); ?>" >
                            <input type="hidden" name="tanggal" id="tanggal" >
                            <input type="hidden" name="qty" id="qty-langsung" value="1" >
                            <input type="hidden" name="total" id="total">
                            <button class="primary-btn" data-toggle="tooltip" data-placement="right" title="Beli Sekarang">Buy Now</button>
                        </form>
                        

                        <ul>
                            <li><b>Stok Produk</b> <span><?php echo e($dtl->stok); ?> tersedia </span></li>
                            <li><b>Berat</b> <span><?php echo e($dtl->berat); ?> gram</span></li>
                            <li><b>Share on</b>
                                <div class="share">
                                    <a href="https://www.facebook.com/profile.php?id=100072698470651"><i class="fa fa-facebook"></i></a>
                                    <a href="https://www.instagram.com/idh.cahaya/"><i class="fa fa-instagram"></i></a>
                                    <a href="#"><i class="fa fa-whatsapp"></i></a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>

<?php $__env->startPush('script'); ?>
<script>
    $('#input-qty').change(function(e){
        e.preventDefault();
        var input_qty = $(this).val();
        $('#qty-langsung').val(input_qty);
    })
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/frontend/produk/detail_barang.blade.php ENDPATH**/ ?>