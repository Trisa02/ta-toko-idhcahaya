<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light rounded h-100 p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Profil Admin</h6>
                        <a href="<?php echo e(route('tambah-admin')); ?>">Tambah Admin</a>
                    </div>
                    <form>
                        <div class="form-group">
                            <img src="<?php echo e(asset('gambar/'.$admin->gambar)); ?>" width="30%" height="30%" class="rounded-circle" alt="Cinque Terre">
                        </div>
                        <div class="row mb-3">
                            <label for="nama admin" class="col-sm-4 col-form-label">Nama Admin</label>
                            <div class="col-sm-8">
                                <label for="inputEmail3" class="col-sm-6 col-form-label"><?php echo e($admin->nama_admin); ?></label>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="username" class="col-sm-4 col-form-label">Username</label>
                            <div class="col-sm-8">
                                <label for="username" class="col-sm-6 col-form-label"><?php echo e($admin->username); ?></label>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="username" class="col-sm-4 col-form-label">Status</label>
                            <div class="col-sm-8">
                                <label for="username" class="col-sm-6 col-form-label"><?php echo e($admin->level_user); ?></label>
                            </div>
                        </div>
                        <a href="<?php echo e(route('edit-admin',$admin->id_admin)); ?>"  class="btn btn-primary">Edit Data</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/admin/profil_admin.blade.php ENDPATH**/ ?>