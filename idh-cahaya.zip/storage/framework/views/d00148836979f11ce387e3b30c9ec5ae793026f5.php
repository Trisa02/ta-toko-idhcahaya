
<?php $__env->startSection('content'); ?>
    <section class="breadcrumb-section set-bg" data-setbg="<?php echo e(asset('/')); ?>img/banner2.png">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2 class="text-dark">Detail Transaksi</h2>
                        <div class="breadcrumb__option">
                            <a href="<?php echo e(route('index-frontend')); ?>">Home</a>
                            <a href="./index.html">Keranjang Produk</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <br>
    <div class="container-fluid pt-10">
        <div class="row px-xl-18">
            <div class="col-md-2"></div>
            <div class="col-lg-8">
                <div class="checkout__order">
                    <div class="">
                        <h4 class="font-weight-semi-bold m-0">Detail Transaksi</h4>
                    </div>

                    <div class="checkout__order">
                        <h6 class="font-weight-bold">Invoice : <?php echo e($selesai->order_id); ?></h6>
                        <br>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <h6 class="font-weight-bold">Alamat Pengiriman</h6>
                                    <h6 class="font-weight-medium"><?php echo e($user->nama_member); ?></h6>
                                    <h6 class="font-weight-medium"><?php echo e($user->alamat_member); ?></h6>
                                    <h6 class="font-weight-medium"><?php echo e($user->no_telepon); ?></h6>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <h6 class="font-weight-bold">Kurir</h6>
                                    <h6 class="font-weight-medium"><?php echo e($selesai->kurir); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Rincian Barang</h5>
                            <h6 class="font-weight-bold"></h6>
                        </div>
                        <table class="table">
                            <?php
                                $sub_total = 0;
                            ?>
                                <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="width: 70%"><img src="<?php echo e(asset('gambar/'.$item->gambar)); ?>" alt="" style="width: 50px;"><?php echo e($item->nama_barang); ?></td>
                                        <td><b><?php echo e($item->qty); ?>pcs</b> </td>
                                        <th>:</th>
                                        <td>Rp.<?php echo e(number_format($item->harga)); ?></td>
                                    </tr>
                                    <?php
                                        $sub_total+=$item->harga;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Rincian Pesanan</h5>
                        </div>
                            <table class="table">
                                <tr>
                                    <th style="width: 80%">Sub Total Produk</th>
                                    <th>:</th>
                                    <td>Rp.<?php echo e($sub_total); ?></td>
                                </tr>
                                <tr>
                                    <th style="width: 80%">Ongkir</th>
                                    <th>:</th>
                                    <td >Rp.<?php echo e(number_format($selesai->ongkir)); ?></td>
                                </tr>
                                <tr>
                                    <th style="width: 80%">Total belanja</th>
                                    <th>:</th>
                                    <td >Rp.<?php echo e(number_format($selesai->total_bayar)); ?></td>
                                </tr>
                            </table>

                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Pembayaran</h5>
                        </div>
                        <table class="table">
                            <tr>
                                <th style="width: 80%">Metode Pembayaran</th>
                                <th>:</th>
                                <td><?php echo e($selesai->payment_type); ?></td>
                            </tr>
                            <tr>

                                <th style="width: 80%">Status Pembayaran</th>
                                <th>:</th>
                                <td>
                                    <?php if($selesai->transaction_status == 'settlement'): ?>
                                        Sudah Melakukan Pembayaran
                                     <?php else: ?>
                                        Menunggu Pembayaran
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                </div>
            </div>
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/frontend/Transaksi/view_transaksi.blade.php ENDPATH**/ ?>