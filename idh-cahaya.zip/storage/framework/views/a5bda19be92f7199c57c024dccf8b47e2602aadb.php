<?php $__env->startSection('content'); ?>
<section class="hero">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="hero__categories">
                    <div class="hero__categories__all" data-toggle="collapse" href="#navbar-vertical" style="height: 50px; margin-top: 1px; padding: 1 30px;">
                        <i class="fa fa-bars"></i>
                        <span>Kategori Produk</span>
                    </div>
                    <nav class="collapse show navbar navbar-vertical  align-items-start p-0 border border-top-0 border-bottom-0"
                    id="navbar-vertical" style="overflow: scroll">
                        <div class="navbar-nav w-100" style="height: 400px;">
                            <ul>
                                <li> <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href=""
                                        class="nav-item nav-link"><?php echo e($ktr->nama_kategori); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="hero__search">
                    <div class="hero__search__form">
                        <form action="#">
                            <input type="text" placeholder="What do yo u need?">
                            <button type="submit" class="site-btn">SEARCH</button>
                        </form>
                    </div>
                    <div class="hero__search__phone">
                        <div class="hero__search__phone__icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="hero__search__phone__text">
                            <h5>+65 11.188.888</h5>
                            <span>support 24/7 time</span>
                        </div>
                    </div>
                </div>
                <div class="hero__item set-bg" data-setbg="<?php echo e(asset('/')); ?>logincss/images/TOKO.png">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="featured spad">
    <div class="container">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Belanja Produk</h2>
                    </div>
                </div>
            </div>
        <div class="row featured__filter">
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mix oranges fresh-meat">
                    <div class="featured__item">
                        <div class="featured__item__pic set-bg" data-setbg="<?php echo e(asset('gambar/'.$brg->gambar)); ?>">
                            <ul class="featured__item__pic__hover">
                                <li><a href="#" data-toggle="tooltip" data-placement="right" title="Favorit"><i class="fa fa-heart"></i></a></li>
                                <li><a href="#" data-toggle="tooltip" data-placement="right" title="Detail"><i class="fa fa-eye"></i></a></li>
                                <li><a href="#" data-toggle="tooltip" data-placement="right" title="Keranjang"><i class="fa fa-shopping-cart"></i></a></li>
                            </ul>
                        </div>
                        <div class="featured__item__text">
                            <h6><a href="#"><?php echo e($brg->nama_barang); ?></a></h6>
                            <h5>Rp.<?php echo e(number_format($brg->harga)); ?></h5>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/home.blade.php ENDPATH**/ ?>