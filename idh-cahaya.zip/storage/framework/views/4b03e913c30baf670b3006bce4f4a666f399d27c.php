<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-6">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Edit Admin</h6>
                <form action="<?php echo e(route('save-edit-admin')); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <input type="hidden" name="id_admin" value="<?php echo e($admin->id_admin); ?>" class="form-control">
                    </div>
                    <div class="row mb-3">
                        <label for="nama_admin" class="col-sm-4 col-form-label">Nama Admin</label>
                        <div class="col-sm-10">
                            <input type="text" name="nama_admin" value=<?php echo e($admin->nama_admin); ?> class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="username" class="col-sm-4 col-form-label">Username</label>
                        <div class="col-sm-10">
                            <input type="text" name="username" value="<?php echo e($admin->username); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="nama_kategori" class="form-label">Level Admin</label>
                        <select id="level_user" name="level_user" class="form-select">
                            <option selected>Pilih Kategori...</option>
                            <?php $__currentLoopData = $leveladmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->level_user); ?>"><?php echo e($item->level_user); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <label for="password" class="col-sm-4 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password" name="password" value="<?php echo e($admin->password); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <img src="<?php echo e(asset('gambar/'.$admin->gambar)); ?>" width="50%" height="50%">
                    </div>
                    <div class="row mb-3">
                        <label for="">Gambar</label>
                        <div class="col-sm-10">
                        <input type="file" name="gambar" class="form-control" placeholder="Gambar">
                        </div>
                    </div>
                    <br>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block ">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/admin/edit_admin.blade.php ENDPATH**/ ?>