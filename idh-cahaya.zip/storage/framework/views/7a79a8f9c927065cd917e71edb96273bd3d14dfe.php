<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="row g-8">
            <div class="col-sm-20 col-xl-10">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Tambah Barang Idh.Cahaya</h6>
                    <form class="row g-3" enctype="multipart/form-data" action="<?php echo e(route('save-edit-barang')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <input type="hidden" name="id_barang" value="<?php echo e($barang->id_barang); ?>" class="form-control">
                        </div>
                        <div class="col-md-6">
                          <label for="nama_barang" class="form-label">Nama Barang</label>
                          <input type="text" class="form-control" name="nama_barang" value="<?php echo e($barang->nama_barang); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="nama_kategori" class="form-label">Nama Kategori</label>
                            <select id="nama_kategori" name="id_kategori" class="form-select">
                                <option value="" disabled selected>Pilih Kategori...</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($isi->id_kategori); ?>"><?php echo e($isi->nama_kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <script>
                                    document.getElementById('id_kategori').value = '<?php echo e($barang->id_kategori); ?>'
                                </script>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="text" name="stok" class="form-control" id="stok" value="<?php echo e($barang->stok); ?>">
                          </div>
                          <div class="col-md-4">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="text" name="harga" class="form-control" id="harga" value="<?php echo e($barang->harga); ?>">
                          </div>
                          <div class="col-md-2">
                            <label for="berat" class="form-label">Berat</label>
                            <input type="text" name="berat" class="form-control" id="berat" value=<?php echo e($barang->berat); ?>>
                          </div>
                        <div class="col-12">
                          <label for="detail" class="form-label">Detail Barang</label>
                          <textarea class="form-control" name="detail" cols="30" rows="5"><?php echo e($barang->detail); ?></textarea>
                        </div>
                        <div class="form-group">
                            <img src="<?php echo e(asset('gambar/'.$barang->gambar)); ?>" width="50%" height="50%">
                        </div>
                        <div class="form-group">
                            <input type="file" name="gambar" >
                        </div>
                        <div class="col-12">
                          <button type="submit" class="btn btn-primary">Save Barang</button>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/backend/barang/edit_barang.blade.php ENDPATH**/ ?>