<?php $__env->startSection('content'); ?>
<section class="featured spad">
    <div class="container">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Belanja Produk</h2>
                    </div>
                </div>
            </div>
        <div class="row featured__filter">
            <?php $__currentLoopData = $detail_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mix oranges fresh-meat">
                <div class="featured__item">
                    <div class="featured__item__pic set-bg" data-setbg="<?php echo e(asset('gambar/'.$dk->gambar)); ?>">
                        <ul class="featured__item__pic__hover">
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="Favorit"><i class="fa fa-heart"></i></a></li>
                            <li><a href="<?php echo e(route('detail-barang',$dk->slug_barang)); ?>" data-toggle="tooltip" data-placement="right" title="Detail"><i class="fa fa-eye"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" data-placement="right" title="Keranjang"><i class="fa fa-shopping-cart"></i></a></li>
                        </ul>
                    </div>
                    <div class="featured__item__text">
                        <h6><a href="#"><?php echo e($dk->nama_barang); ?></a></h6>
                        <h5>Rp.<?php echo e(number_format($dk->harga)); ?></h5>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\idh-cahaya\idh-cahaya\resources\views/frontend/produk/produk_perkategori.blade.php ENDPATH**/ ?>